package com.example.search_page;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Adapter;
import android.widget.Filter;
import android.widget.Toast;

import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private MaterialSearchView searchView;
    private Toolbar toolbar;
    private RecyclerView listView;
    private ArrayList<String> arrayList = new ArrayList();
    private ArrayList<String> arrayListSQL;
    private MAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (RecyclerView) findViewById(R.id.view);
        //populating the array via list
        // in the place of Foods you select a string array of recipe names from database
        arrayList.addAll(Arrays.asList(getResources().getStringArray(R.array.Foods)));
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        adapter = new MAdapter(arrayList);
        //initializing the searchView
        searchViewCode();

    }

    private void searchViewCode() {
        searchView = (MaterialSearchView) findViewById(R.id.searchView);
        searchView.setSuggestions(getResources().getStringArray(R.array.Foods));
        searchView.setEllipsize(true);
        searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                Toast.makeText(getApplicationContext(), query, Toast.LENGTH_SHORT).show();
                searchView.closeSearch();
                listView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                List<String> filteredList = filter(arrayList, query);
                listView.setAdapter(new MAdapter(filteredList));

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return true;
            }
        });

        searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {
            @Override
            public void onSearchViewShown() {
            }

            @Override
            public void onSearchViewClosed() {
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        MenuItem item = menu.findItem(R.id.searchAction);
        searchView.setMenuItem(item);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.searchAction:
                //here is stuff for going somewhere else
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        if (searchView.isSearchOpen()) {
            searchView.closeSearch();
        } else {
            super.onBackPressed();
        }
    }

    private List<String> filter(List<String> exampleList, String constraint) {
        List<String> filteredList = new ArrayList<>();
        if (constraint == null || constraint.length() == 0) {
            filteredList.addAll(exampleList);
        } else {
            String filterPattern = constraint.toString().toLowerCase().trim();
            for (Object item : exampleList) {
                if (item.toString().toLowerCase().contains(filterPattern)) {
                    filteredList.add(item.toString());
                }
                ;
            }
        }
        return filteredList;
    }
}
