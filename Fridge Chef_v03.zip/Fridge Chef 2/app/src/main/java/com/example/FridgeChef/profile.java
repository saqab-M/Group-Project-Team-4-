package com.example.FridgeChef;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class profile extends AppCompatActivity {

    TextView mFullname, mUsername, mFollowers, mRecipes;
    ImageView mProfileImage;
    FirebaseAuth fAuth;
    FirebaseFirestore db;
    StorageReference storageRef;
    String userID;

    private static final String TAG = "tag";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        mFullname = findViewById(R.id.fullName);
        mUsername = findViewById(R.id.username);
        mFollowers = findViewById(R.id.followers);
        mRecipes = findViewById(R.id.recipes);
        mProfileImage = findViewById(R.id.profileImage);


        fAuth = FirebaseAuth.getInstance();
        userID = fAuth.getCurrentUser().getUid();
        db = FirebaseFirestore.getInstance();
        storageRef = FirebaseStorage.getInstance().getReference();

        StorageReference profileRef = storageRef.child("users/" + userID +"/profile.jpg");

        profileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(mProfileImage);
            }
        });

        DocumentReference documentReference = db.collection("users").document(userID);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                mFullname.setText(documentSnapshot.getString("fullname"));
                mUsername.setText(documentSnapshot.getString("username"));
                int followers = documentSnapshot.getDouble("followersCount").intValue();
                mFollowers.setText(String.valueOf(followers));
                int recipes = documentSnapshot.getDouble("recipesCount").intValue();
                mRecipes.setText(String.valueOf(recipes));
            }
        });


    }

    /* Drop-Down UI methods*/
    public void openProfile(View view) {
        // already in profile
    }

    public void openHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void openMyFridge(View view) {
        Intent intent = new Intent(this, MyFridge.class);
        startActivity(intent);
    }

    public void openSettings(View view) {
        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }
}

