package com.example.FridgeChef;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class MyFridge extends AppCompatActivity {


    ArrayList<String> fridgeIngredients = new ArrayList<String>(); //Array list storing the ingredients retrieved from firestore
    FirebaseAuth fAuth;
    FirebaseUser user;
    String userID;
    FirebaseFirestore db;
    private ListView fridgeList;
    private ArrayAdapter<String> fridgeAdapter;
    Boolean isPro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_fridge);

        isPro = false;

        //Get the current instances from Firebase so we can perform the various operations
        fAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        //Get the logged in user
        user = fAuth.getCurrentUser();
        //Get the users unique ID
        userID = user.getUid();

        DocumentReference documentReference = db.collection("users").document(userID);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                isPro = documentSnapshot.getBoolean("isPro");
                Log.d("tag", "user is pro:" + isPro);
            }
        });

        fridgeList = findViewById(R.id.foodList);

        fridgeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, fridgeIngredients);
        fridgeList.setAdapter(fridgeAdapter);
        fridgeAdapter.notifyDataSetChanged();

        fridgeList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                final String itemToRemove = fridgeAdapter.getItem(position);
                int iend = itemToRemove.indexOf("q");
                String foodToRemove = itemToRemove.substring(0, iend).trim();
                Toast.makeText(MyFridge.this, foodToRemove, Toast.LENGTH_SHORT).show();

                //delete from firebase

                //Logged in users path to their virtual fridge document where we will delete the food item
                final CollectionReference foodInFridgeRef = db.collection("virtualFridge/" + userID + "/foods");

                Query recipeQuery = foodInFridgeRef.whereEqualTo("name", foodToRemove);

                recipeQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            if (task.getResult().isEmpty()) {
                                Log.d("TAG", "empty set result food delete");

                            }
                            // Go through all the foods in the virtual fridge document
                            for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
                                Log.d("TAG", documentSnapshot.getId() + " => " + documentSnapshot.getData());
                                foodInFridgeRef.document(documentSnapshot.getId()).delete();
                                fridgeAdapter.remove(itemToRemove);
                                fridgeAdapter.notifyDataSetChanged();

                            }
                        }
                        else {
                            Log.d("TAG", "delete food query failed");
                        }
                    }
                });


            }
        });

        Log.d("TAG", "fridgepage opened!");

        //Logged in users path to their virtual fridge document where we will retrieve their stored food items
        CollectionReference fridgeItemsRef = db.collection("virtualFridge/" + userID + "/foods");

        Query recipeQuery = fridgeItemsRef.orderBy("name");

        recipeQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().isEmpty()) {
                        Log.d("TAG", "empty set result recipes");

                    }
                    // Go through all the foods in the virtual fridge document
                    for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
                        Log.d("TAG", documentSnapshot.getId() + " => " + documentSnapshot.getData());
                        fridgeAdapter.add(documentSnapshot.get("name").toString() + " quantity: " + documentSnapshot.get("quantity").toString());
                        fridgeAdapter.notifyDataSetChanged();

                    }
                } else {
                    Log.d("TAG", "Unsuccessful");
                }
            }
        });


    }


    /* Drop-Down UI methods*/
    public void openProfile(View view) {
        Intent intent = new Intent(this, profile.class);
        startActivity(intent);
    }

    public void openHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void openMyFridge(View view) {
        // already in MyFridge
    }

    public void openSettings(View view) {
        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }

    public void openIngredientPage(View view) {
        Intent intent = new Intent(this, AddIngredients.class);
        startActivity(intent);
    }

    public void toShoppingList(View view) {
        Intent intent = new Intent(this, ShoppingList.class);
        startActivity(intent);
    }

    public void toRecipes(View view) {
        if (isPro) {
            Intent intent = new Intent(this, ManageRecipes.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "You are not a pro user!", Toast.LENGTH_SHORT).show();
        }
    }
}
