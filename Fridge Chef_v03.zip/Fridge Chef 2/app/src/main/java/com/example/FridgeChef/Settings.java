package com.example.FridgeChef;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

public class Settings extends AppCompatActivity {
    FirebaseAuth fAuth;
    FirebaseUser user;
    String userID;
    FirebaseFirestore db;
    StorageReference storageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        fAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        user = fAuth.getCurrentUser();
        storageRef = FirebaseStorage.getInstance().getReference();
    }

    /* Drop-Down UI methods*/
    public void openProfile(View view) {
        Intent intent = new Intent(this, profile.class);
        startActivity(intent);
        finish();
    }

    public void openHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void openMyFridge(View view) {
        Intent intent = new Intent(this, MyFridge.class);
        startActivity(intent);
        finish();
    }

    public void openSettings(View view) {
        // already in settings
    }

    public void logout(View view) {
        //Sign the user out
        FirebaseAuth.getInstance().signOut();
        finish();
        startActivity(new Intent(getApplicationContext(), Login.class));
    }

    public void changePass(View view) {
        Intent intent = new Intent(this, ChangePassword.class);
        startActivity(intent);
    }

    public void changeUsername(View view) {
        userID = user.getUid();
        final EditText updateUsername = new EditText(view.getContext());
        final AlertDialog.Builder usernameChange = new AlertDialog.Builder(view.getContext());
        usernameChange.setTitle("Change username");
        usernameChange.setMessage("Enter your new username");
        usernameChange.setView(updateUsername);

        usernameChange.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final String newUsername = updateUsername.getText().toString();

                if (newUsername.isEmpty()) {
                    updateUsername.setError("You must enter a new username");
                    Toast.makeText(Settings.this, "Username failed to update: You must enter a new username", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    //Query to see if the inputted new username already exists
                    CollectionReference userRef = db.collection("users");
                    Query usernameQuery = userRef.whereEqualTo("username", newUsername);

                    usernameQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                //If empty set returned from query change the users username
                                if (task.getResult().isEmpty()) {
                                    Map<String, Object> user = new HashMap<>();
                                    user.put("username", newUsername);

                                    DocumentReference documentReference = FirebaseFirestore.getInstance()
                                            .collection("users").document(userID);

                                    documentReference.update(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Toast.makeText(Settings.this, "Username updated", Toast.LENGTH_SHORT).show();

                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(Settings.this, "Username failed to update " + e.getMessage(), Toast.LENGTH_SHORT).show();

                                        }
                                    });
                                } else {
                                    Toast.makeText(Settings.this, "This username already exists!", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(Settings.this, "Query failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }
            }
        });

        usernameChange.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Close dialog
            }
        });

        usernameChange.create().show();
    }

    public void changeProfile(View view) {
        Intent openGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(openGallery, 1000);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1000) {
            if (resultCode == Activity.RESULT_OK) {
                Uri imageUri = data.getData();
                uploadImageToFirebase(imageUri);
            }
        }
    }

    private void uploadImageToFirebase(Uri imageUri) {
        StorageReference fileRef = storageRef.child("users/" + user.getUid() +"/profile.jpg");
        fileRef.putFile(imageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Toast.makeText(Settings.this, "Profile picture updated!", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                        // ...
                        Toast.makeText(Settings.this, "Image upload failed", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
