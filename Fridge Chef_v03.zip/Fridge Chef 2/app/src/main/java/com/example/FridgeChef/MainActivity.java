package com.example.FridgeChef;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> recipeList = new ArrayList<String>(); //Array list storing recipes retrieved from firestore
    ArrayList<String> usersList = new ArrayList<String>(); //Array list storing users retrieved from firestore
    FirebaseAuth fAuth;
    FirebaseUser user;
    String userID;
    FirebaseFirestore db;
    private ListView mRecipesList, mUsersList;
    private ArrayAdapter<String> recipeAdapter, userAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Get the current instances from Firebase so we can perform the various operations
        fAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        //Get the logged in user
        user = fAuth.getCurrentUser();
        //Get the users unique ID
        userID = user.getUid();

        //Connect variable to resources on the page
        mRecipesList = findViewById(R.id.topRecipesList);
        mUsersList = findViewById(R.id.topUsersList);

        recipeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, recipeList);
        userAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, usersList);

        mRecipesList.setAdapter(recipeAdapter);
        mUsersList.setAdapter(userAdapter);
        recipeAdapter.notifyDataSetChanged();
        userAdapter.notifyDataSetChanged();

        mRecipesList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
            }
        });

        mUsersList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
            }
        });

        //Query top 10 most popular recipes
        CollectionReference recipeRef = db.collection("recipe");
        Query recipeQuery = recipeRef.orderBy("likeCount", Query.Direction.DESCENDING).limit(10);

        recipeQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().isEmpty()) {
                        Log.d("TAG", "empty set result recipes");

                    }
                    // Go through all the recipes made by the user in the recipe document
                    for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
                        Log.d("TAG", documentSnapshot.getId() + " => " + documentSnapshot.getData());
                        recipeAdapter.add(documentSnapshot.get("name").toString());
                        Log.d("TAG", recipeAdapter.toString());
                        recipeAdapter.notifyDataSetChanged();

                    }
                } else {
                    Log.d("TAG", "query failed");
                }
            }
        });

        //Query top 10 most popular users
        CollectionReference userRef = db.collection("users");
        Query userQuery = userRef.orderBy("followersCount", Query.Direction.DESCENDING).limit(10);

        userQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().isEmpty()) {
                        Log.d("TAG", "empty set result recipes");

                    }
                    // Go through all the recipes made by the user in the recipe document
                    for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
                        Log.d("TAG", documentSnapshot.getId() + " => " + documentSnapshot.getData());
                        userAdapter.add(documentSnapshot.get("username").toString());
                        Log.d("TAG", recipeAdapter.toString());
                        userAdapter.notifyDataSetChanged();
                    }
                } else {
                    Log.d("TAG", "query failed");
                }
            }
        });

    }

    /* Drop-Down UI methods*/
    public void openProfile(View view) {
        Intent intent = new Intent(this, profile.class);
        startActivity(intent);
    }

    public void openHome(View view) {
        // already in home page
    }

    public void openMyFridge(View view) {
        Intent intent = new Intent(this, MyFridge.class);
        startActivity(intent);
    }

    public void openSettings(View view) {
        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }
}
