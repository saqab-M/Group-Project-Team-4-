package com.example.FridgeChef;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class MyFridge extends AppCompatActivity {

    RecyclerView mIngredientsList;
    ArrayList<String> fridgeIngredients = new ArrayList<>(); //Array list storing the ingredients retrieved from firestore
    FirebaseAuth fAuth;
    FirebaseUser user;
    String userID;
    FirebaseFirestore db;
    StorageReference storageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_fridge);
        mIngredientsList = findViewById(R.id.ingredientsList);

        //Get the current instances from Firebase so we can perform the various operations
        fAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        //Get the logged in user
        user = fAuth.getCurrentUser();
        //Get the users unique ID
        userID = user.getUid();

        //Logged in users path to their virtual fridge document where we will retrieve their stored food items
        CollectionReference fridgeItemsRef = db.collection("virtualFridge/" + userID + "/foods/");

        fridgeItemsRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()) {
                    // Go through all the foods in the virtual fridge document
                    for (QueryDocumentSnapshot documentSnapshot: task.getResult()) {
                        Log.d("TAG", documentSnapshot.getId() + " => " + documentSnapshot.getData());
                        //Get the foods name
                        String foodName = documentSnapshot.get("name").toString();
                        //Get the quantity
                        String foodQuantity = documentSnapshot.get("quantity").toString() + "g/ml";
                        String foodInFridge = foodName + " " + foodQuantity;
                        fridgeIngredients.add(foodInFridge);
                        Log.d("TAG", fridgeIngredients.toString());
                    }
                }
                else {
                    Log.d("TAG", "Unsuccessful");
                }
            }
        });


    }


    /* Drop-Down UI methods*/
    public void openProfile(View view) {
        Intent intent = new Intent(this, profile.class);
        startActivity(intent);
    }

    public void openHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void openMyFridge(View view) {
        // already in MyFridge
    }

    public void openSettings(View view) {
        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }

    public void openIngredientPage(View view) {
        Intent intent = new Intent(this, AddIngredients.class);
        startActivity(intent);
    }

    public void toShoppingList(View view) {
        Intent intent = new Intent(this, ShoppingList.class);
        startActivity(intent);
    }

}
