package com.example.FridgeChef;

public class FridgeModel {

    private String foodID;
    private String name;
    private long quantity;

    private FridgeModel(String foodID, String name, long quantity) {
        this.foodID = foodID;
        this.name = name;
        this.quantity = quantity;
    }

    public String getFoodID() {
        return foodID;
    }

    public String getName() {
        return name;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setFoodID(String foodID) {
        this.foodID = foodID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }
}

