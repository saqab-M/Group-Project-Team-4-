package com.example.FridgeChef;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddIngredients extends AppCompatActivity {

    FirebaseAuth fAuth;
    FirebaseFirestore db;
    FirebaseUser user;
    StorageReference storageRef;
    String userID;
    Spinner mSpinnerIngredientUnits;
    String ingredientName;
    String ingredientQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ingredients);
        fAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        user = fAuth.getCurrentUser();
        storageRef = FirebaseStorage.getInstance().getReference();
        userID = user.getUid();

        mSpinnerIngredientUnits = findViewById(R.id.unitSpinner); //getting spinner
        List<String> unitTypes = new ArrayList<String>(); //new array list
        unitTypes.add("ml"); //adding different unit type to list
        unitTypes.add("g");
        unitTypes.add("tbsp");
        unitTypes.add("tsp");
        unitTypes.add("N/A");

        ArrayAdapter<String> unitAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, unitTypes); //setting the spinner adapter to hold thos values
        mSpinnerIngredientUnits.setAdapter(unitAdapter);//adding the adapter to the spinner

    }

    public void addIngredient(View view) {
        EditText Ingredient_Name = findViewById(R.id.input_ingredient);
        EditText Quantity = findViewById(R.id.input_quantity);
        Spinner SpinnerIngredientUnits = (Spinner) findViewById(R.id.unitSpinner);
        String units = SpinnerIngredientUnits.getSelectedItem().toString();

        ingredientName = Ingredient_Name.getText().toString().trim();
        ingredientQuantity = Quantity.getText().toString();

        if (ingredientName.isEmpty()) {
            Ingredient_Name.setError("You must enter an ingredient!");
            return;
        }
        if (ingredientQuantity.isEmpty()) {
            Quantity.setError("You must enter a quantity!");
            return;
        }

        if(units=="N/A") {
            units = "";
        }

        ingredientQuantity+=units;

        //Query to see if the inputted ingredient already exists
        CollectionReference foodRef = db.collection("foodItem");
        Query foodQuery = foodRef.whereEqualTo("name", ingredientName);

        foodQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    // if inputted ingredient doesn't already exist add it to the foods document
                    if (task.getResult().isEmpty()) {
                        // Add food item to food collection
                        Map<String, Object> food = new HashMap<>();
                        food.put("name", ingredientName);

                        // Add a new food document with a generated ID
                        db.collection("foodItem")
                                .add(food)
                                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                    @Override
                                    public void onSuccess(DocumentReference documentReference) {
                                        Log.d("TAG", "DocumentSnapshot added with ID: " + documentReference.getId());
                                        String foodID = documentReference.getId();

                                        //Add food to users fridge
                                        Map<String, Object> fridge = new HashMap<>();
                                        fridge.put("foodID", foodID);
                                        fridge.put("name", ingredientName);
                                        fridge.put("quantity", ingredientQuantity);

                                        final DocumentReference fridgeRef = FirebaseFirestore.getInstance()
                                                .collection("virtualFridge/" + userID + "/foods").document();

                                        fridgeRef.set(fridge).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    Log.d("TAG", "Food item added" + fridgeRef.getId());

                                                } else {
                                                    Log.d("TAG", "Error adding " + task.getException());
                                                }
                                            }
                                        });
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.w("TAG", "Error adding document", e);
                                    }
                                });
                        // food item already exists
                    } else {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Log.d("TAG", document.getId() + " => " + document.getData());
                            // get id of the food
                            String foodID = document.getId();

                            Map<String, Object> fridge = new HashMap<>();
                            fridge.put("foodID", foodID);
                            fridge.put("name", ingredientName);
                            fridge.put("quantity", ingredientQuantity);

                            // add food to the users virtual fridge
                            final DocumentReference fridgeRef = FirebaseFirestore.getInstance()
                                    .collection("virtualFridge/" + userID + "/foods").document();

                            fridgeRef.set(fridge).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Log.d("TAG", "Food item added" + fridgeRef.getId());

                                    } else {
                                        Log.d("TAG", "Error adding " + task.getException());
                                    }
                                }
                            });


                        }
                    }

                } else {
                    Toast.makeText(AddIngredients.this, "Query failed " + task.getException(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Go back to fridge page

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
