package com.example.FridgeChef;

public class Recipe {
    private String title;
    private int imageID;

    //constructor
    public Recipe(String title, int imageID) {
        this.title = title;
        this.imageID = imageID;
    }

    //get methods
    public String getTitle() {
        return this.title;
    }

    public int getImageID() {
        return this.imageID;
    }
}
