package com.example.FridgeChef;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class AddRecipeMethod extends AppCompatActivity {

    FirebaseAuth fAuth;
    FirebaseFirestore db;
    FirebaseUser user;
    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_recipe_method);
        //Get the current instances from Firebase so we can perform the various operations
        fAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        //Get the logged in user
        user = fAuth.getCurrentUser();
        //Get the users unique ID
        userID = user.getUid();


    }


    public void submitRecipe(View view) {
        EditText EditTextMethod = (EditText) findViewById(R.id.editTextMethod); //getting the method

        String RecipeIngredients = getIntent().getExtras().getString("Ingredients"); //gets the Ingredients from previous activity
        String RecipeTitle = getIntent().getExtras().getString("RecipeTitle"); //gets Title from previous activity
        String RecipeMethod = EditTextMethod.getText().toString().trim(); //gets recipe instructions from edit text

        if (RecipeMethod.isEmpty()) {
            EditTextMethod.setError("You must enter the recipe's instructions");
            return;
        }
        //need to put the firebase code here

        // Create a new recipe
        Map<String, Object> recipe = new HashMap<>();
        recipe.put("userID", userID);
        recipe.put("name", RecipeTitle);
        recipe.put("ingredients", RecipeIngredients);
        recipe.put("instructions", RecipeMethod);
        recipe.put("viewCount", 0);
        recipe.put("likeCount", 0);


        // Add a new document with a generated ID
        db.collection("recipe")
                .add(recipe)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d("TAG", "recipe added with ID: " + documentReference.getId());

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("TAG", "Error adding document", e);
                    }
                });

        final DocumentReference userRef = db.collection("users/").document(userID);
        userRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    int recipes = task.getResult().getDouble("recipesCount").intValue();
                    recipes++;
                    userRef.update("recipesCount", recipes).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Log.d("tag", "recipes incremented");
                            }
                        }
                    });
                }
            }
        });

        Intent intent = new Intent(this, ManageRecipes.class);
        startActivity(intent);
    }
}
