package com.example.FridgeChef;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class ManageRecipes extends AppCompatActivity {

    ArrayList<String> recipes = new ArrayList<String>(); //Array list storing the ingredients retrieved from firestore
    ArrayList<String> savedRecipes = new ArrayList<String>(); //Array list storing the ingredients retrieved from firestore
    FirebaseAuth fAuth;
    FirebaseUser user;
    String userID;
    FirebaseFirestore db;
    private ListView recipesList, savedRecipesList;
    private ArrayAdapter<String> recipeAdapter, savedRecipesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_recipes);
        //Get the current instances from Firebase so we can perform the various operations
        fAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        //Get the logged in user
        user = fAuth.getCurrentUser();
        //Get the users unique ID
        userID = user.getUid();

        recipesList = findViewById(R.id.recipeList);

        recipeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, recipes);
        recipesList.setAdapter(recipeAdapter);
        recipeAdapter.notifyDataSetChanged();

        recipesList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String recipeName = recipeAdapter.getItem(position);
                Intent intent = new Intent(ManageRecipes.this, RecipePage.class);
                intent.putExtra("recipeName", recipeName);
                startActivity(intent);
            }
        });

        savedRecipesList = findViewById(R.id.savedRecipeListView);

        savedRecipesAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, savedRecipes);
        savedRecipesList.setAdapter(savedRecipesAdapter);
        savedRecipesAdapter.notifyDataSetChanged();

        savedRecipesList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String recipeName = savedRecipesAdapter.getItem(position);
                Intent intent = new Intent(ManageRecipes.this, RecipePage.class);
                intent.putExtra("recipeName", recipeName);
                startActivity(intent);
            }
        });

        //Query recipes made by the logged in user
        CollectionReference recipeRef = db.collection("recipe");
        Query recipeQuery = recipeRef.whereEqualTo("userID", userID);

        recipeQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().isEmpty()) {
                        Log.d("TAG", "empty set result recipes");

                    }
                    // Go through all the recipes made by the user in the recipe document
                    for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
                        Log.d("TAG", documentSnapshot.getId() + " => " + documentSnapshot.getData());
                        recipeAdapter.add(documentSnapshot.get("name").toString());
                        recipeAdapter.notifyDataSetChanged();

                    }
                } else {
                    Log.d("TAG", "query failed");
                }
            }
        });

        //Query recipes saved by the logged in user
        final CollectionReference savedRecipeRef = db.collection("users/" + userID + "/savedRecipes");
        Query savedRecipeQuery = savedRecipeRef.orderBy("name");

        savedRecipeQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().isEmpty()) {
                        Log.d("TAG", "empty set result saved recipes");

                    }
                    // Go through all the recipes made by the user in the recipe document
                    for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
                        Log.d("TAG", documentSnapshot.getId() + " => " + documentSnapshot.getData());
                        savedRecipesAdapter.add(documentSnapshot.get("name").toString());
                        savedRecipesAdapter.notifyDataSetChanged();

                    }
                } else {
                    Log.d("TAG", "query failed");
                }
            }
        });

    }


    /* Drop-Down UI methods*/
    public void openProfile(View view) {
        Intent intent = new Intent(this, profile.class);
        startActivity(intent);
    }

    public void openHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void openMyFridge(View view) {
        Intent intent = new Intent(this, MyFridge.class);
        startActivity(intent);
    }

    public void openSettings(View view) {
        Intent intent = new Intent(this, Settings.class);
        startActivity(intent);
    }

    public void addRecipe(View view) {
        Intent intent = new Intent(this, AddRecipeIngredients.class);
        startActivity(intent);
    }

    public void toSearch(View view) {
        Intent intent = new Intent(this, SearchRecipes.class);
        startActivity(intent);
    }
}
