package com.example.FridgeChef;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.util.ArrayList;
import java.util.List;


public class SearchRecipes extends AppCompatActivity {

    private MaterialSearchView searchView;
    private Toolbar toolbar;
    private RecyclerView listView;
    private ArrayList<String> recipesList = new ArrayList();
    private MAdapter adapter;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_recipes);

        db = FirebaseFirestore.getInstance();

        toolbar = findViewById(R.id.toolbar);

        adapter = new MAdapter(recipesList);

        listView = findViewById(R.id.view);
        //populating the array via list
        // in the place of Foods you select a string array of recipe names from database

        db.collection("recipe")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG", document.getId() + " => " + document.getData());
                                recipesList.add(document.getString("name"));
                                adapter.setList(recipesList);
                                adapter.notifyDataSetChanged();

                            }
                        } else {
                            Log.w("TAG", "Error getting recipes", task.getException());
                        }
                    }
                });

        adapter.notifyDataSetChanged();
        recipesList.addAll(adapter.getList());
        Log.d("TAG", "recipes " + recipesList.toString());
        Log.d("TAG", "adapter " + adapter.getList().toString());
        //initializing the searchView
        searchViewCode();

    }

    private void searchViewCode() {
        searchView = (MaterialSearchView) findViewById(R.id.searchView);
        searchView.setSuggestions(recipesList.toArray(new String[0]));
        searchView.setEllipsize(true);
        searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchView.closeSearch();
                listView.setLayoutManager(new LinearLayoutManager(SearchRecipes.this));
                List<String> filteredList = filter(recipesList, query);
                listView.setAdapter(new MAdapter(filteredList));

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return true;
            }
        });

        searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {
            @Override
            public void onSearchViewShown() {
            }

            @Override
            public void onSearchViewClosed() {
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        MenuItem item = menu.findItem(R.id.searchAction);
        searchView.setMenuItem(item);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.searchAction:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        if (searchView.isSearchOpen()) {
            searchView.closeSearch();
        } else {
            super.onBackPressed();
        }
    }

    private List<String> filter(List<String> exampleList, String constraint) {
        List<String> filteredList = new ArrayList<>();
        if (constraint == null || constraint.length() == 0) {
            filteredList.addAll(exampleList);
        } else {
            String filterPattern = constraint.toString().toLowerCase().trim();
            for (Object item : exampleList) {
                if (item.toString().toLowerCase().contains(filterPattern)) {
                    filteredList.add(item.toString());
                }
                ;
            }
        }
        return filteredList;
    }
}
