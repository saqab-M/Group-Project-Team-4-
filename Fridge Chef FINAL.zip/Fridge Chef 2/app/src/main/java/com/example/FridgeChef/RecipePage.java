package com.example.FridgeChef;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class RecipePage extends AppCompatActivity {

    TextView mRecipeName, mUserName, mIngredients, mInstructions, mLikesText;
    FirebaseAuth fAuth;
    FirebaseUser user;
    String userID;
    FirebaseFirestore db;
    String recipeName;
    Boolean alreadySaved = true;
    int likeCount;
    Boolean isPro = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_page);

        mRecipeName = findViewById(R.id.recipeName);
        mUserName = findViewById(R.id.usernameText);
        mIngredients = findViewById(R.id.ingredientsText);
        mInstructions = findViewById(R.id.methodText);
        mLikesText = findViewById(R.id.likesText);

        //Get the current instances from Firebase so we can perform the various operations
        fAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        //Get the logged in user
        user = fAuth.getCurrentUser();
        //Get the users unique ID
        userID = user.getUid();

        //Check if the user is a pro user
        DocumentReference documentReference = db.collection("users").document(userID);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                isPro = documentSnapshot.getBoolean("isPro");
                Log.d("tag", "user is pro:" + isPro);
            }
        });

        //gets the recipe name from previous activity
        recipeName = getIntent().getExtras().getString("recipeName");

        //Query recipes by name from previous activity
        CollectionReference recipeRef = db.collection("recipe");
        Query recipeQuery = recipeRef.whereEqualTo("name", recipeName);

        recipeQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().isEmpty()) {
                        Log.d("TAG", "empty set result recipe");

                    }
                    // Go through all the recipes made by the user in the recipe document
                    for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
                        Log.d("TAG", documentSnapshot.getId() + " => " + documentSnapshot.getData());
                        mRecipeName.setText(documentSnapshot.getString("name"));
                        mIngredients.setText(documentSnapshot.getString("ingredients"));
                        mInstructions.setText(documentSnapshot.getString("instructions"));
                        mLikesText.setText("Likes: " + documentSnapshot.get("likeCount").toString());

                        //Get username of recipe creator
                        String userID = documentSnapshot.getString("userID");

                        Log.d("TAG1", "userID" + userID);

                        //Query to get username of user who created recipe
                        DocumentReference documentReference = db.collection("users").document(userID);
                        documentReference.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    mUserName.setText("Chef: " + task.getResult().getString("username"));
                                } else {
                                    Log.d("TAG", "query failed");
                                }
                            }
                        });

                    }
                } else {
                    Log.d("TAG", "query failed");
                }
            }
        });


    }


    public void likeRecipe(View view) {
        //Query recipes by name from previous activity
        final CollectionReference recipeRef = db.collection("recipe");
        final Query recipeQuery = recipeRef.whereEqualTo("name", recipeName);

        recipeQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().isEmpty()) {
                        Log.d("TAG", "empty set result recipe");

                    }
                    // Go through all the recipes made by the user in the recipe document
                    for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
                        Log.d("TAG", documentSnapshot.getId() + " => " + documentSnapshot.getData());
                        final String recipeID = documentSnapshot.getId();
                        String recipeUserID = documentSnapshot.getString("userID");
                        likeCount = documentSnapshot.getDouble("likeCount").intValue();
                        Log.d("TAG", "currentUserID " + userID + " recipe userID " + recipeUserID);
                        if (userID.equals(recipeUserID)) {
                            Log.d("TAG1", "currentUserID " + userID + " recipe userID " + recipeUserID);
                            Toast.makeText(RecipePage.this, "Cannot like your own recipe!", Toast.LENGTH_SHORT).show();
                        } else {
                            final DocumentReference likedByRef = db.collection("recipe/" + recipeID + "/likedBy").document();
                            Query recipeQuery = db.collection("recipe/" + recipeID + "/likedBy").whereEqualTo("likedByUser", userID);
                            recipeQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                    if (task.isSuccessful()) {
                                        if (task.getResult().isEmpty()) {
                                            likeCount++;
                                            recipeRef.document(recipeID).update("likeCount", likeCount).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    Log.d("TAG", "DocumentSnapshot successfully updated!");
                                                    final Map<String, Object> likedRecipe = new HashMap<>();
                                                    likedRecipe.put("likedByUser", userID);
                                                    likedByRef.set(likedRecipe).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {
                                                            if (task.isSuccessful()) {
                                                                Log.d("TAG", "Like recipe updated");
                                                            } else {
                                                                Log.d("TAG", "Like recipe failed " + task.getException());
                                                            }
                                                        }
                                                    });
                                                    finish();
                                                    startActivity(getIntent());
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Log.w("TAG", "Error updating document", e);

                                                }
                                            });
                                        } else {
                                            Toast.makeText(RecipePage.this, "You have already liked this recipe", Toast.LENGTH_SHORT).show();
                                        }
                                    } else {
                                        Log.d("tag", "query failed " + task.getException());
                                    }
                                }
                            });
                        }
                    }
                } else {
                    Log.d("TAG", "query failed");
                }
            }
        });


    }

    public void saveRecipe(View view) {

        final Map<String, Object> recipe = new HashMap<>();


        //Query recipes by name from previous activity
        final CollectionReference recipeRef = db.collection("recipe");
        Query recipeQuery = recipeRef.whereEqualTo("name", recipeName);

        recipeQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().isEmpty()) {
                        Log.d("TAG", "empty set result recipe");

                    }
                    // Go through all the recipes made by the user in the recipe document
                    for (QueryDocumentSnapshot documentSnapshot : task.getResult()) {
                        Log.d("TAG", documentSnapshot.getId() + " => " + documentSnapshot.getData());
                        // Create recipe object using recipe details
                        if (userID.equals(documentSnapshot.getString("userID"))) {
                            alreadySaved = false;
                        }
                        recipe.put("name", recipeName);
                        recipe.put("chefID", documentSnapshot.getString("userID"));
                        recipe.put("ingredients", documentSnapshot.getString("ingredients"));
                        recipe.put("instructions", documentSnapshot.getString("instructions"));
                    }

                    if (alreadySaved) {

                        if (!isPro) {
                            Toast.makeText(RecipePage.this, "You are not a pro user!", Toast.LENGTH_SHORT).show();
                        } else {
                            Query recipeQuery = db.collection("users/" + userID + "/savedRecipes").whereEqualTo("name", recipeName);
                            recipeQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                    if (task.isSuccessful()) {
                                        if (!task.getResult().isEmpty()) {
                                            Toast.makeText(RecipePage.this, "You have already saved this recipe", Toast.LENGTH_SHORT).show();
                                        } else {

                                            //add to users saved recipes
                                            DocumentReference savedRecipes = db.collection("/users/" + userID + "/savedRecipes/").document();

                                            savedRecipes.set(recipe).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                        Log.d("TAG", "Recipe saved");
                                                        Toast.makeText(RecipePage.this, "Recipe saved", Toast.LENGTH_SHORT).show();
                                                    } else {
                                                        Log.d("TAG", "Recipe failed to save " + task.getException());
                                                    }
                                                }
                                            });
                                        }
                                    }
                                }
                            });
                        }

                    } else {
                        Toast.makeText(RecipePage.this, "This recipe is already stored as you're its chef", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Log.d("TAG", "query failed");
                }
            }
        });


    }
}
