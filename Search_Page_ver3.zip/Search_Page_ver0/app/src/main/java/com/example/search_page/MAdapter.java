package com.example.search_page;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import org.jetbrains.annotations.NotNull;

public final class MAdapter extends RecyclerView.Adapter<MAdapter.ViewHolder> implements Filterable {
    private final List list;
    private List resultList;
    private List exampleList;

    @NotNull
    public MAdapter.ViewHolder onCreateViewHolder(@NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row, parent, false);
        return new MAdapter.ViewHolder(view);
    }

    public int getItemCount() {
        return this.list.size();
    }

    public void onBindViewHolder(@NotNull MAdapter.ViewHolder holder, int position) {
        View view = holder.getView().findViewById(R.id.title);
        ((TextView)view).setText((CharSequence)this.list.get(position));
    }

    public MAdapter(@NotNull List list) {
        super();
        this.list = list;
        exampleList = new ArrayList<String>(list);
    }

    public static final class ViewHolder extends RecyclerView.ViewHolder {
        @NotNull
        private final View view;

        @NotNull
        public final View getView() {
            return this.view;
        }

        public ViewHolder(@NotNull View view) {
            super(view);
            this.view = view;
        }
    }

    @NotNull
    public Filter getFilter(){
        return exampleFilter;
    }

    private Filter exampleFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<String> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0){
                filteredList.addAll(exampleList);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (Object item : exampleList){
                    if(item.toString().toLowerCase().contains(filterPattern)){
                        filteredList.add(item.toString());
                    };
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            resultList.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };
}