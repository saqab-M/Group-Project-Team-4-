package com.example.search_page;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        String query = getIntent().getStringExtra(EXTRA_QUERY);
        TextView queryTextView = (TextView) findViewById(R.id.queryTextView);
        queryTextView.setText(query);

    }

    public static final String EXTRA_QUERY = "extra_query";

    public static void startActivity(Context context, String query) {
        Intent intent = new Intent(context, DetailsActivity.class);
        intent.putExtra(EXTRA_QUERY, query);
        context.startActivity(intent);
    }
}
