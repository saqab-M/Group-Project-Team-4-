package com.example.gp_recipecreator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddRecipeMethod extends AppCompatActivity implements View.OnClickListener
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_recipe_method);


    }

    @Override
    public void onClick(View v)
    {
        if(v.getId() == R.id.buttonSubmit)
        {
            EditText EditTextMethod = (EditText)findViewById(R.id.editTextMethod); //getting the method

            String RecipeIngredients = getIntent().getExtras().getString("Ingredients"); //gets the Ingredients from previous activity
            String RecipeTitle = getIntent().getExtras().getString("RecipeTitle"); //gets Title from previous activity
            String RecipeMethod = EditTextMethod.getText().toString(); //

            if(RecipeMethod.equals(""))//checking a method has been entered
            {
                Toast.makeText(getApplicationContext(),"No Method",Toast.LENGTH_SHORT).show(); //using a toast to give user a warning
            }
            else
            {
                //need to put the firebase code here

                //code to return app to main should also be put here
            }

        }
    }
}
