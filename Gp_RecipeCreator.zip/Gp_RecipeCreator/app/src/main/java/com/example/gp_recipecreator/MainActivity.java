package com.example.gp_recipecreator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnRecipesPage = (Button)findViewById(R.id.BtnRecipesPage);
        btnRecipesPage.setOnClickListener(this);

    }


    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.BtnRecipesPage)
        {



            Intent startIntent = new Intent(getApplicationContext(), AddIngredients.class);//running next activity
           // startIntent.putExtra("User_ID_Value", "ID123456"); //this needs to be plugged in from the rest of the app
           startActivity(startIntent);
        }
    }
}
