package com.example.gp_recipecreator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class AddIngredients extends AppCompatActivity implements View.OnClickListener
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ingredients);

        Button btnAddIngredient = (Button) findViewById(R.id.btnAddIngredients); //getting button
        btnAddIngredient.setOnClickListener(this);//adding on click listener

        Button btnSubmit = (Button)findViewById(R.id.buttonNext);
        btnSubmit.setOnClickListener(this);

        Spinner SpinnerIngredientUnits = (Spinner) findViewById(R.id.spinnerUnit); //getting spinner
        List<String> unitTypes = new ArrayList<String>(); //new array list
        unitTypes.add("ml"); //adding diffrenet uni type to list
        unitTypes.add("g");
        unitTypes.add("tbsp");
        unitTypes.add("tsp");
        unitTypes.add("N/A *");

        ArrayAdapter<String> unitAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, unitTypes); //setting the spinner adapter to hold thos values
        SpinnerIngredientUnits.setAdapter(unitAdapter);//adding the adapter to the spinner
    }

    @Override
    public void onClick(View v)
    {
        if (v.getId() == R.id.btnAddIngredients) //if its the add ingredients button
        {
            String toSet = addIngredient(); //running method and stroing return
            TextView textViewIngredients = (TextView)findViewById(R.id.textViewIngredients);
            String currentHolder = textViewIngredients.getText().toString();
            if(toSet.equals(""))//if the value returned was blank do nothing
            {
            }
            else
            {
                textViewIngredients.setText(currentHolder + " " + toSet); //if its not blank set the text view
            }
        }
        if (v.getId()== R.id.buttonNext) //if its the next button
        {
            TextView textViewIngredients = (TextView)findViewById(R.id.textViewIngredients);//getting the text view
            EditText editTextTitle = (EditText)findViewById(R.id.editTextTitle);
            String Ingredients = textViewIngredients.getText().toString();//getting contents of text view
            String RecipeTitle = editTextTitle.getText().toString();//getting contents

            if(Ingredients.equals("") || RecipeTitle.equals(""))//getting there are values
            {
                Toast.makeText(getApplicationContext(),"Missing Field",Toast.LENGTH_SHORT).show(); //error message
            }
            else
            {
                Intent startIntent = new Intent(getApplicationContext(), AddRecipeMethod.class);
                startIntent.putExtra("Ingredients", Ingredients); //this needs to be plugged in from the rest of the app
                startIntent.putExtra("RecipeTitle", RecipeTitle);
                startActivity(startIntent); //starting the next activity
            }
        }
    }

    String addIngredient()
    {
        //int num1 = Integer.parseInt(firstNumEditText.getText().toString());

        EditText editTextIngredient = (EditText) findViewById(R.id.editTextIngredientName); //loading in all the values from the xml
        EditText editTextQuantity = (EditText) findViewById(R.id.editTextQuantity);
        Spinner SpinnerIngredientUnits = (Spinner) findViewById(R.id.spinnerUnit);
        String units = SpinnerIngredientUnits.getSelectedItem().toString(); //getting spinner value

        String IngredientName = editTextIngredient.getText().toString(); //getting Ingredient
        String Quantity = editTextQuantity.getText().toString();//getting quantity

        String toReturn = ""; //defining string

        if(IngredientName.equals("") || Quantity.equals("")) //checking value are present
        {
            Toast.makeText(getApplicationContext(),"Missing Field",Toast.LENGTH_SHORT).show(); //error toast
        }
        else
        {
            editTextIngredient.setText("");//emptying fields so next value can be entered
            editTextQuantity.setText("");

            toReturn = IngredientName + ": " + Quantity + units + ", "; //new to return value
        }



        return toReturn;//returning
    }
}
