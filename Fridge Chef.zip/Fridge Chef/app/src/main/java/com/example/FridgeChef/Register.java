package com.example.FridgeChef;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {
    private static final String TAG = "TAG";
    //Create variables for the text inputs and buttons on the register page
    EditText mFullName, mUsername, mEmail, mPassword, mConfirmPassword;
    CheckBox mVegetarianCheck, mVeganCheck, mPescatarianCheck;
    Boolean isVegetarian = false;
    Boolean isVegan = false;
    Boolean isPescatarian = false;
    Button mRegisterBtn;
    TextView mLoginBtn;
    ProgressBar progressBar;

    //Variables for firebase
    FirebaseAuth fAuth;
    FirebaseFirestore db;
    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //Connect variables to the resources on the page
        mFullName = findViewById(R.id.regFullName);
        mUsername = findViewById(R.id.regUsername);
        mEmail = findViewById(R.id.regEmail);
        mPassword = findViewById(R.id.regPassword);
        mConfirmPassword = findViewById(R.id.confirmPassword);
        mVegetarianCheck = findViewById(R.id.checkVegetarian);
        mVeganCheck = findViewById(R.id.checkVegan);
        mPescatarianCheck = findViewById(R.id.checkPescatarian);
        mRegisterBtn = findViewById(R.id.registerBtn);
        mLoginBtn = findViewById(R.id.toLogin);
        progressBar = findViewById(R.id.registerProgressBar);
        //Get the current instances from Firebase so we can perform the various operations
        fAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        //Set dietary requirements variables based on the checkboxes
        mVegetarianCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isVegetarian = mVegetarianCheck.isChecked();
            }
        });

        mVeganCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isVegan = mVeganCheck.isChecked();
            }
        });

        mPescatarianCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isPescatarian = mPescatarianCheck.isChecked();
            }
        });


        //When the register button is clicked
        mRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get the full name, username, email, password and confirm password from the text input fields
                final String fullname = mFullName.getText().toString().trim();
                final String username = mUsername.getText().toString().trim();
                final String email = mEmail.getText().toString().trim();
                final String password = mPassword.getText().toString().trim();
                final String confirmPass = mConfirmPassword.getText().toString().trim();

                //Check if the input for full name is empty
                if (TextUtils.isEmpty(fullname)) {
                    mFullName.setError("Enter a full name");
                    return;
                }
                //Check if the input username is empty
                if (TextUtils.isEmpty(username)) {
                    mUsername.setError("Enter a username");
                    return;
                }
                //Check if the input for email is empty
                if (TextUtils.isEmpty(email)) {
                    mEmail.setError("Enter an email");
                    return;
                }
                //Check if the input for password is empty
                if (TextUtils.isEmpty(password)) {
                    mPassword.setError("Enter a password");
                    return;
                }
                //Check if the length of the password is less than 6 characters
                if (password.length() < 6) {
                    mPassword.setError("Password must be greater than 6 characters");
                    return;
                }
                //Check if the input for confirm password is empty
                if (TextUtils.isEmpty(confirmPass)) {
                    mConfirmPassword.setError("Enter a password");
                    return;
                }
                //Check if the length of confirm password is less than 6 characters
                if (confirmPass.length() < 6) {
                    mConfirmPassword.setError("Password must be greater than 6 characters");
                    return;
                }
                //Check if the confirm password and password are not equal
                if (!confirmPass.equals(password)) {
                    mConfirmPassword.setError("Passwords don't match");
                    return;
                }

                //Query too see if the supplied username already exists
                CollectionReference userRef = db.collection("users");
                Query usernameQuery = userRef.whereEqualTo("username", username);

                usernameQuery.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            //If empty set returned from query register the user
                            if (task.getResult().isEmpty()) {
                                //Make the progress bar visible
                                progressBar.setVisibility(View.VISIBLE);

                                //Attempt to register user with email and password and use event listener to determine if the registration was successful or not
                                fAuth.createUserWithEmailAndPassword(email, confirmPass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        //If the registration is successful
                                        if (task.isSuccessful()) {
                                            //Show success message
                                            Toast.makeText(Register.this, "User registered", Toast.LENGTH_SHORT).show();

                                            //Create virtual fridge for new user
                                            Map<String, Object> fridge = new HashMap<>();
                                            // Add dummy food items
                                            fridge.put("foodID", "/foodItem/DdhnwScNG7qwHCdnUt9S");
                                            fridge.put("quantity", 0);

                                            final DocumentReference fridgeDoc = db.collection("virtualFridge").document();
                                            fridgeDoc.set(fridge).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    Log.d(TAG, "Fridge added with ID: " + fridgeDoc.getId());
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Log.w(TAG, "Error adding document", e);
                                                }
                                            });
                                            //Get the users ID
                                            userID = fAuth.getCurrentUser().getUid();

                                            Map<String, Object> user = new HashMap<>();

                                            //Create a new user document with the userID as the unique identifier for the document
                                            DocumentReference usersDoc = db.collection("users").document(userID);
                                            user.put("fullname", fullname);
                                            user.put("username", username);
                                            user.put("isVegetarian", isVegetarian);
                                            user.put("isVegan", isVegan);
                                            user.put("isPescatarian", isPescatarian);
                                            user.put("followersCount", 0);
                                            user.put("recipesCount", 0);
                                            user.put("fridgeID", "/virtualFridge/" + fridgeDoc.getId());
                                            user.put("isPro", false);

                                            usersDoc.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    Log.d(TAG, "User added with ID: " + userID);
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Log.w(TAG, "Error adding document", e);
                                                }
                                            });

                                            //Send user to the main activity
                                            startActivity(new Intent(getApplicationContext(), Login.class));
                                            finish();
                                        }
                                        //If the registration is unsuccessful
                                        else {
                                            //Show error message
                                            Toast.makeText(Register.this, "Error in registration " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                            progressBar.setVisibility(View.GONE);


                                        }
                                    }
                                });


                            } else {
                                mUsername.setError("This username already exists");
                                return;
                            }
                        } else {
                            Toast.makeText(Register.this, "Query failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });

        //When the login text field is clicked
        mLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Send user to the login activity
                startActivity(new Intent(getApplicationContext(), Login.class));
                finish();
            }
        });
    }
}
