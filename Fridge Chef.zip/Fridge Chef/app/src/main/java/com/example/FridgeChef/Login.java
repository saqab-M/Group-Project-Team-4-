package com.example.FridgeChef;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    //Create variables for the text inputs and buttons on the login page
    EditText mEmail, mPassword;
    Button mLoginBtn;
    TextView mRegisterBtn, mForgotPass;
    ProgressBar progressBar;
    FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Connect variables to the resources on the page
        mEmail = findViewById(R.id.lEmail);
        mPassword = findViewById(R.id.lPassword);
        mLoginBtn = findViewById(R.id.loginBtn);
        mRegisterBtn = findViewById(R.id.toRegister);
        mForgotPass = findViewById(R.id.forgotPass);
        progressBar = findViewById(R.id.loginProgressBar);
        fAuth = FirebaseAuth.getInstance();

        //When the user clicks the login button
        mLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Retrieve email and password from the text fields
                String email = mEmail.getText().toString().trim();
                String password = mPassword.getText().toString().trim();

                //Check if the input for email is empty
                if (TextUtils.isEmpty(email)) {
                    mEmail.setError("Enter an email");
                    return;
                }
                //Check if the input for password is empty
                if (TextUtils.isEmpty(password)) {
                    mPassword.setError("Enter a password");
                    return;
                }
                //Make the progress bar visible
                progressBar.setVisibility(View.VISIBLE);

                //Authenticate the user
                fAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        //If the registration is successful
                        if (task.isSuccessful()) {
                            //Show message to the user that they've successfully logged in
                            Toast.makeText(Login.this, "Logged in successfully", Toast.LENGTH_SHORT).show();
                            //Send user to the main activity
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            finish();
                        }
                        //If the registration is unsuccessful
                        else {
                            //Show error message
                            Toast.makeText(Login.this, "Error in login: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);


                        }
                    }
                });

            }
        });

        //When the user clicks the register text field
        mRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Send user to the register activity
                startActivity(new Intent(getApplicationContext(), Register.class));
                finish();
            }
        });

        //When the user clicks the forgot password label
        mForgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Text field for the alert dialog
                final EditText resetMail = new EditText(v.getContext());

                //Set the text for alert dialog to the text in the email text field if it's not empty
                if (!mEmail.getText().toString().isEmpty()) {
                    resetMail.setText(mEmail.getText().toString().trim());
                }
                //Create alert dialog to send password reset link to inputted email
                final AlertDialog.Builder passwordResetDialog = new AlertDialog.Builder(v.getContext());
                passwordResetDialog.setTitle("Reset password");
                passwordResetDialog.setMessage("Enter your email to receive a password reset link");
                passwordResetDialog.setView(resetMail);

                //When user clicks Send on the alert dialog attempt to send the password reset link
                passwordResetDialog.setPositiveButton("Send", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Retrieve inputted email
                        String email = resetMail.getText().toString();
                        if (!(email.isEmpty())) {
                            fAuth.sendPasswordResetEmail(email).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(Login.this, "A password reset link has been sent to your email", Toast.LENGTH_SHORT).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(Login.this, "Error in sending the password reset link " + e.getMessage(), Toast.LENGTH_LONG).show();

                                }
                            });
                        } else {
                            Toast.makeText(Login.this, "Please enter an email", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                passwordResetDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Close dialog
                    }
                });

                passwordResetDialog.create().show();
            }
        });

    }
}
