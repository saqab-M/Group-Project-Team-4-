package com.example.FridgeChef;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Set;

public class ChangePassword extends AppCompatActivity {
    private static final String TAG = "tag";
    FirebaseAuth fAuth;
    EditText mCurrPass, mNewPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        mCurrPass = findViewById(R.id.currPass);
        mNewPass = findViewById(R.id.newPass);

        fAuth = FirebaseAuth.getInstance();
    }

    public void changePass(View view) {
        Log.d(TAG, "Change pass clicked");
        final FirebaseUser user = fAuth.getCurrentUser();
        String currentPassword = mCurrPass.getText().toString();
        final String newPassword = mNewPass.getText().toString();

        //Check if the input for the current  password is empty
        if (TextUtils.isEmpty(currentPassword)) {
            mCurrPass.setError("Enter your current password");
            return;
        }

        //Check if the input for the new password is empty
        if (TextUtils.isEmpty(newPassword)) {
            mNewPass.setError("Enter the new password");
            return;
        }
        //Check if the length of the new password is greater than 6 characters
        if (newPassword.length() < 6) {
            mNewPass.setError("Password must be greater than 6 characters");
            return;
        }

        AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), currentPassword);

        user.reauthenticate(credential).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    user.updatePassword(newPassword)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Log.d(TAG, "User password updated.");
                                        Toast.makeText(ChangePassword.this, "Password changed!", Toast.LENGTH_SHORT).show();
                                        finish();

                                    }
                                }
                            });
                } else {
                    mCurrPass.setError("Invalid password entered");
                    Toast.makeText(ChangePassword.this, "Current password invalid", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }

    public void closeBtn(View view) {
        Intent intent = new Intent(ChangePassword.this, Settings.class);
        startActivity(intent);
        finish();
    }
}
