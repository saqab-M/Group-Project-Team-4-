package com.example.my_fridge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Add_Ingredients extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.my_fridge.Message";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__ingredients);
    }

    public void Add_Input_Ingredient(View view){

        // send input back to the fridge
        Intent intent = new Intent(this, MainActivity.class);
        EditText Ingredient_Name = findViewById(R.id.input_ingredient);
        EditText Quantity = findViewById(R.id.input_quantity);
        String input = (Ingredient_Name.getText().toString() + " " + Quantity.getText().toString());
        intent.putExtra(EXTRA_MESSAGE, input);
        startActivity(intent);


    }

}
