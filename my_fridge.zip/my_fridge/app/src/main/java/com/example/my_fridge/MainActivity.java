package com.example.my_fridge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    ListView Ingredient_ListView;

    // ----------------- change data source to database ---------------
    //      Becouse ingredients are currently stored in an array, the array gets reinitalized
    //      evrytime, so the input is lost. but if i was getting input from a database the code
    //      would work.


    String[] old_ingredients = {"milk 3", "eggs 4",}; //arr
    int IndexOfSelectedItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get input from the add_Ingredients page
        Intent intent = getIntent();
        String new_Ingredient = intent.getStringExtra(Add_Ingredients.EXTRA_MESSAGE);

        int items = old_ingredients.length;

        //when displaying the page load ingredients from database/array
        //this if statment stops the program from trying to get input if there is none.
        if (new_Ingredient != null){
            old_ingredients = plus1_Ingredient(items, old_ingredients, new_Ingredient);
        }

        LoadList();

        // use array adapter to get data from the array to the list view
       // Ingredient_ListView = findViewById(R.id.Ingredient_List);
        //ArrayAdapter<String> ingredientAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, old_ingredients);
        //Ingredient_ListView.setAdapter(ingredientAdapter);

        Ingredient_ListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Toast.makeText(MainActivity.this,old_ingredients[position],Toast.LENGTH_SHORT).show();
                IndexOfSelectedItem = position;

            }
        });


    }



    // add items to array
    private String[] plus1_Ingredient(int items, String[] old_ingredients, String new_ingredient) {

        String newArray[] = new String[items+1];
        for(int i=0; i < items ; i++){
            newArray[i] = old_ingredients[i];
        }
        newArray[items] = new_ingredient;
        return newArray;
    }

    // remove items from array
    private String[] minus1_ingredient(int items, String[] old_ingredients, int IndexOfSelectedItem){

        String newArray[] = new String[items-1];
        old_ingredients[IndexOfSelectedItem]= "X";
        int X_found = 0;
        for(int i=0;i<items;i++){
            if(old_ingredients[i] != "X"){
                newArray[i-X_found] = old_ingredients[i];
            }else{
                X_found=1;
            }
        }

        return newArray;
    }


    // when Add buttun clicked
    public void openIngredientPage(View view){
        Intent intent = new Intent(this, Add_Ingredients.class);
        startActivity(intent);
    }

    //when delete button is clicked
    public void DeleteItem(View view){
        int items = old_ingredients.length;
        old_ingredients=minus1_ingredient(items,old_ingredients,IndexOfSelectedItem);
        LoadList();
    }


    public void LoadList(){
        // use array adapter to get data from the array to the list view
        Ingredient_ListView = findViewById(R.id.Ingredient_List);
        ArrayAdapter<String> ingredientAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, old_ingredients);
        Ingredient_ListView.setAdapter(ingredientAdapter);



        return;
    }
}
